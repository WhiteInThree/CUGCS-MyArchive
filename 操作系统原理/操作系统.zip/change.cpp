#include <iostream>
#include <algorithm>
#include <iomanip>
#include <time.h>

using namespace std;

const int num_instructions = 320;
int arr_instructions[num_instructions + 6];

struct Node
{
    int instructions = 0;
    int time = 0;
    Node* link = NULL;
};

int random(int min, int max)
{
    return rand() % (max - min + 1) + min;
}

void GenerateInstructions()
{
    int i = 0;
    while (i < num_instructions)
    {
        int M = random(1, 30);
        arr_instructions[i++] = M;
        arr_instructions[i++] = M + 1;
        int M1 = random(0, M - 1);
        arr_instructions[i++] = M1;
        arr_instructions[i++] = M1 + 1;
        int M2 = random(M1 + 2, 30);
        arr_instructions[i++] = M2;
        arr_instructions[i++] = M2 + 1;
    }
}

double FIFO(int size)
{
    Node* head = new Node;
    Node* tail = head;
    int failure = 0;
    for (int i = 0; i < num_instructions; i++)
    {
        int current = arr_instructions[i];
        int hit = 0;
        for (Node* p = head->link; p != NULL; p = p->link)
        {
            if (p->instructions == current)
            {
                hit = 1;
            }
        }
        if (!hit)
        {
            failure++;
            if (head->instructions >= size)
            {
                head->link = head->link->link;
            }
            else
                head->instructions++;
            tail->link = new Node;
            tail = tail->link;
            tail->instructions = current;
            tail->link = NULL;
        }
    }
    return 1.0 - (double)failure / num_instructions;
}

double LRU(int size)
{ 
    Node* head = new Node;
    Node* tail = head;
    int failure = 0;
    int clock = 999;
    for (int i = 0; i < num_instructions; i++)
    {
        clock--;
        int current = arr_instructions[i];
        int hit = 0;
        for (Node* p = head->link; p != NULL; p = p->link)
        {
            if (p->instructions == current)
            {
                hit = 1;
                p->time = clock;
            }
        }
        if (!hit)
        {
            failure++;
            if (head->instructions >= size)
            {
                Node* t = new Node;
                t->time = -1;
                for (Node* p = head->link; p != NULL; p = p->link)
                {
                    if (p->time > t->time)
                        t = p;
                }
                t->instructions = current;
                t->time = clock;
            }
            else
            {
                head->instructions++;
                tail->link = new Node;
                tail = tail->link;
                tail->instructions = current;
                tail->link = NULL;
            }  
        }
    }
    return 1.0 - (double)failure / num_instructions;
}

double OPT(int size)
{
    Node* head = new Node;
    Node* tail = head;
    int failure = 0;
    for (int i = 0; i < num_instructions; i++)
    {
        int current = arr_instructions[i];
        int hit = 0;
        for (Node* p = head->link; p != NULL; p = p->link)
        {
            if (p->instructions == current)
                hit = 1;
        }
        if (!hit)
        {
            failure++;
            if (head->instructions >= size)
            {
                for (Node* p = head->link; p != NULL; p = p->link)
                {
                    p->time = 999;
                    for (int j = i + 1; j < num_instructions; j++)
                    {
                        if (p->instructions == arr_instructions[i])
                        {
                            p->time = j - i;
                            break;
                        }
                    }
                }
                Node* t = new Node;
                t->time = -1;
                for (Node* p = head->link; p != NULL; p = p->link)
                {
                    if (p->time > t->time)
                        t = p;
                }
                t->instructions = current;
                
            }
            else
            {
                head->instructions++;
                tail->link = new Node;
                tail = tail->link;
                tail->instructions = current;
                tail->link = NULL;
            }
        }
    }
    return 1.0 - (double)failure / num_instructions;
}

int main()
{
    srand(time(0));
    GenerateInstructions();
    cout << "内存页块       FIFO             LRU             OPT" << endl;
    for (int i = 8; i <= 32; i++) {
        cout << i << "\t";
        cout << setw(11) << FIFO(i) << "\t";
        cout << setw(11) << LRU(i) << "\t";
        cout << setw(11) << OPT(i) << "\t";
        cout << endl;
    }
    return 0;
}
