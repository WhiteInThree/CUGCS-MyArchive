#include <iostream>
#include <algorithm>
using namespace std;

void FCFS()
{
	int sum = 0;
	int begin = 90;
	int track[14];
	cout << "请输入磁盘号:" << endl;
	for (int i = 0; i < 14; i++)
	{
		cin >> track[i];
	}
	cout << "磁道访问顺序为：" << endl;
	cout << begin << "-->";
	for (int i = 0; i < 14; i++)
	{
		if (i == 0)
			sum += abs(begin - track[i]);
		else
			sum += abs(track[i - 1] - track[i]);
		if (i == 13)
			cout << track[i] << endl;
		else
			cout << track[i] << "-->";
	}
	cout << endl;
	cout << "平均移动道数为：" << (double)sum/14 << endl;
	system("pause");
}

void SSTF()
{
	struct T
	{
		int id;
		int flag;
		int move;
	}track[14];
	int sum = 0;
	int begin = 90;
	int dis = 0;
	int now;
	int shortest;
	cout << "请输入磁盘号:" << endl;
	for (int i = 0; i < 14; i++)
	{
		cin >> track[i].id;
		track[i].flag = 0;
	}
	int t[14];
	for (int i = 0; i < 14; i++)
	{
		t[i] = track[i].id;
	}
	sort(t, t + 14);
	for (int i = 0; i < 14; i++)
	{
		track[i].id = t[i];
	}
	now = begin;
	cout << "磁道访问顺序为：" << endl;
	cout << begin << "-->";
	for (int i = 0; i < 14; i++)
	{
		
		for (int j = 0; j < 14; j++)
		{
			
			dis = abs(now - track[j].id);
			if (track[j].flag != 1)
			{
				track[j].move = dis;
				
			}
			else
			{
				track[j].move = 0x3f3f3f;
			}
		}

		shortest = 0;
		for (int k = 0; k < 14; k++)
		{
			if (track[k].move == 0x3f3f3f)
				continue;
			if (track[shortest].move > track[k].move)
				shortest = k;
		}
		track[shortest].flag = 1;
		sum += abs(track[shortest].id - now);
		if(i==13)
			cout << track[shortest].id << endl;
		else
			cout << track[shortest].id << "-->";
		now = track[shortest].id;
	}
	cout << endl;
	cout << "平均移动道数为：" << (double)sum / 14 << endl;
	system("pause");
}

bool compare(int a, int b)
{
	return a > b;
}
void SCAN()
{
	int sum = 0, now;
	int begin = 90;
	int htrack[14], ltrack[14];
	int hi = 0, li = 0;
	cout << "请输入磁盘号:" << endl;
	for (int i = 0; i < 14; i++)
	{
		cin >> now;
		if (now >= begin)
		{
			htrack[hi] = now;
			hi++;
		}
		else
		{
			ltrack[li] = now;
			li++;
		}
			
	}
	sort(htrack, htrack + hi);
	sort(ltrack, ltrack + li, compare);
	cout << "磁道访问顺序为：" << endl;
	cout << begin << "-->";
	for (int i = 0; i < hi; i++)
	{
		cout << htrack[i] << "-->";
		sum += abs(begin - htrack[i]);
		begin = htrack[i];
	}
	for (int i = 0; i < li; i++)
	{
		if (i == li-1)
			cout << ltrack[i];
		else
			cout << ltrack[i] << "-->";
		sum += abs(begin - ltrack[i]);
		begin = ltrack[i];
	}
	cout << endl;
	cout << "平均移动道数为：" << (double)sum / 14 << endl;
	system("pause");
}

int main()
{
	int choice = 1;
	while (choice != 0)
	{
		cout << "*********************" << endl;
		cout << "【1】先来先服务法" << endl;
		cout << "【2】最短寻道优先法" << endl;
		cout << "【3】电梯调度法" << endl;
		cout << "*********************" << endl;
		cin >> choice;
		switch (choice)
		{
		case 1:
			FCFS();
			break;
		case 2:
			SSTF();
			break;
		case 3:
			SCAN();
			break;
		case 0:
			return 0;
		default:
			break;
		}
	}
	return 0;
}
