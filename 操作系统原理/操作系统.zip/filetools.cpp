#include<iostream>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<sys/wait.h>
using namespace std;

char filename[20];
int fd;
bool opened=false;
char* argv[4]={"ls","-l",NULL,NULL};

void creat_flie()
{
      cout<<"请输入文件名:"<<endl;
      cin>>filename;
      umask(0000);
      fd=open(filename,O_RDWR | O_CREAT,0666);
      argv[2]=(char*)malloc(20);
      strcpy(argv[2],filename);
      if(fd<0)
      {
            cout<<"文件打开失败！"<<endl;
      }
      else
      {
            opened=1;
            cout<<"打开成功！"<<endl;
      }
}

void read_file()
{
      if(opened==0)
      {
            cout<<"文件未打开！"<<endl;
            return;
      }
      char buf[1024];
      memset(buf,0,sizeof(buf));
      lseek(fd,0,SEEK_SET);
      int renum=read(fd,buf,1024);
      if(renum!=-1)
      {
            cout<<"文件内容为:"<<endl;
            cout<<buf<<endl;
      }
      else
            cout<<"读取文件失败！"<<endl;
}

void write_file()
{
      if(opened==0)
      {
            cout<<"文件未打开！"<<endl;
            return;
      }
      char buf[1024];
      cout<<"请输入文件内容："<<endl;
      cin>>buf;
      int renum=write(fd,buf,strlen(buf));
      if(renum!=-1)
            cout<<"写入成功！"<<endl;
      else
            cout<<"写入失败！"<<endl;
}

void view_file()
{
      if(opened==0)
      {
            cout<<"文件未打开！"<<endl;
            return;
      }
      cout<<"文件权限为："<<endl;
      int renum=execv("/bin/ls",argv);
      if(renum!=-1)
            cout<<"文件权限为:"<<endl;
      else  
            cout<<"查看权限失败！"<<endl;
}

void modify_file()
{
      if(opened==0)
      {
            cout<<"文件未打开！"<<endl;
            return;
      }
      cout<<"600:只有所有者有读写权限。"<<endl;
      cout<<"644:只有所有者有读写权限；而组用户和其他用户只有读权限。"<<endl;
      cout<<"666:所有用户都有文件读、写权限。"<<endl;
      cout<<"700:只有所有者有读、写、执行权限。"<<endl;
      cout<<"711:所有者有读、写、执行权限；而组用户和其他用户只有执行权限。"<<endl;
      cout<<"755:所有者有读、写、执行权限；而组用户和其他用户只有读、执行权限。"<<endl;
      cout<<"777:所有用户都有读、写、执行权限。"<<endl;
      cout<<"请输入新的权限："<<endl;
      int new_mode,mode;
      cin >> new_mode;
      int owner_mode = new_mode / 100;
      int group_mode = new_mode /10 % 10;
      int others_mode = new_mode % 10;
      mode = (owner_mode*8*8)+(group_mode*8)+others_mode;
      int renum = chmod(filename,mode);
      if(renum!=-1)
            cout<<"修改权限成功！"<<endl;
      else
            cout<<"修改权限失败！"<<endl;
}

int main()
{
      int choice = 1;
      while(choice!=0)
      {
            cout<<"******      FileTools      ******"<<endl;
            cout<<"******【1】新建或打开文件 "<<endl;
            cout<<"******【2】读文件 *******"<<endl;
            cout<<"******【3】写文件 *******"<<endl;
            cout<<"******【4】查看文件权限 **"<<endl;
            cout<<"******【5】修改文件权限 **"<<endl;
            cout<<"******【6】关闭文件 *****"<<endl;
            cin>>choice;
            switch(choice)
            {
            case 1:
                  creat_flie();
                  break;
            case 2:
                  read_file();
                  break;
            case 3:
                  write_file();
                  break;
            case 4:
           	  if(fork()==0)
                  	view_file();
                  else
                  	wait(NULL);
                  break;
            case 5:
                  modify_file();
                  break;
            case 6:
                  close(fd);
                  opened=0;
                  cout<<"关闭成功！"<<endl;
                  break;
            default:
                  break;
            }     
      }
      return 0;
}
