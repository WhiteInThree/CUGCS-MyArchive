nasm boot.asm -o boot.bin
dd if=/dev/zero of=emptydisk.img bs=512 count=2880 #生成空白软盘镜像文件
dd if=boot.bin of=boot.img bs=512 count=1 #用 bin file 生成对应的镜像文件
dd if=emptydisk.img of=boot.img skip=1 seek=1 bs=512 count=2879 #在 bin 生成的镜像文件后补上空白，成为合适大小的软盘镜像
rm -f boot.bin
rm -f emptydisk.img


