#include<iostream>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
using namespace std;

const int Size=256;
const int SVkey=75;
int msgqid,pid,*pint,i;
struct msg
{
      long long mtype;
      char mtext[200];
}msg;

void PIPE()
{
      pid_t pid;
      int fd[2];
      char buf[Size];
      char msg[Size];
      memset(buf,0,Size);
      memset(msg,0,Size);
      if(pipe(fd)<0)
      {
            perror("pipe");
            exit(1);
      }
      pid=fork();
      if(pid == 0)
      {
            close(fd[0]);
            sprintf(msg, "%d is sending a message to parent %d by PIPE\n", getpid(),getppid());
            write(fd[1],msg,strlen(msg));
            exit(0);
      }
      else if(pid > 0)
      {
            close(fd[1]);
            sleep(0);
            read(fd[0],buf,Size);
            cout<<buf<<endl;
      }
      else
      {
            perror("fork");
            exit(1);
      }
}

void client()
{
      msgqid = msgget(SVkey,0777);
      pid = getpid();
      pint = (int *)msg.mtext;
      *pint = pid;
      msg.mtype = 1;
      msgsnd(msgqid,&msg,sizeof(int),0);
      msgrcv(msgqid,&msg,200,pid,0);
      cout<<"client: receive reply from pid of "<<*pint<<endl;
      exit(0);
}

void server()
{
      msgqid = msgget(SVkey,0777 | IPC_CREAT);
      msgrcv(msgqid,&msg,200,1,0);
      pint = (int *)msg.mtext;
      pid = *pint;
      cout<<"server: serving for client pid of "<<pid<<endl;
      msg.mtype = pid;
      *pint = getpid();
      msgsnd(msgqid,&msg,sizeof(int),0);
      exit(0);
}

void server_client()
{
      i = fork();
      if(!i)
            server();
      i = fork();
      if(!i)
            client();
      sleep(1);
}

void share()
{
      int id;
      char *addr;
      char message[512];
      id = shmget(75,512,0777 | IPC_CREAT);
      if(fork() == 0)
      {
            sprintf(message,"%d is sending message to parent.",getpid());
            cout<<message<<endl;
            addr = (char*)shmat(id,0,0);
            strcpy(addr,message);
            shmdt(addr);
      }
      else{
            addr = (char*)shmat(id,0,0);
            cout<<addr<<endl;
            shmdt(addr);
            shmctl(id,IPC_RMID,0);
      }
}

int main()
{
      
      int choice;
      while(1)
      {
            cout<<"******进程通信*******"<<endl;
            cout<<"****【1】管道通信****"<<endl;
            cout<<"****【2】消息队列****"<<endl;
            cout<<"****【3】共享存储区***"<<endl;
            cin>>choice;
            switch(choice)
            {
            case 1:
                  PIPE();
                  break;
            case 2:
                  server_client();
                  break;
            case 3:
                  share();
                  break;
            default:
                  break;
            }
      }
      return 0;
}
