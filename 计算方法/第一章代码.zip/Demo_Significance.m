%
% Demo for loss of significance
%
clear all; close all

for k = 0 : -1 : -10
    x = 10^k;
    E1 = (1-cos(x)) / sin(x)^2;
    E2 = 1 / (1+cos(x));
    fprintf('k=%3d, x=%.10f, E1=%.15f, E2=%.15f\n', k, x, E1, E2)
end
    