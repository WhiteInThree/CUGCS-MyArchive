tol = 10^(-5);
kmax = 10000;
x = 2;
s = 1.0; % or some better initial guess
for k = 1:kmax
    s = 0.5 * (s + x/s);
    if(abs(s^2 - x) < tol), break; end
end
s